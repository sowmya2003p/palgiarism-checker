# Palgrism checker
 This is kind of an idea how to make palgarism checker in Python.
